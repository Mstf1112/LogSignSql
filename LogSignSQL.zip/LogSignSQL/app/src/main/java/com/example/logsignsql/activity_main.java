package com.example.logsignsql;

import android.app.Activity;

public class activity_main extends Activity {
}
